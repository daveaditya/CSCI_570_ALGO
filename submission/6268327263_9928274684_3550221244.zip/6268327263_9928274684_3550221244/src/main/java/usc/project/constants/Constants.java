package main.java.usc.project.constants;

import java.util.HashMap;
import java.util.Map;

public class Constants {

    public static final String OUTPUT_FILE = "./output.txt";
    public static final long KILOBYTE = 1024L;

}
